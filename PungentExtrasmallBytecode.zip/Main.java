class Main {
  public static void main(String[] args) {
    int color = "rgb("+(255+(d*2))+","+(0+(d*4))+","+(255+(d*6))+")";
  }
}